-- 既存の該当テーブルのデータを削除

-- dtb_order_itemのデータを削除
DELETE FROM dtb_order_item;

-- dtb_shippinngのデータを削除
DELETE FROM dtb_shipping;

-- dtb_mail_historyのデータを削除
DELETE FROM dtb_mail_history;

-- dtb_orderを削除
DELETE FROM dtb_order;

-- dtb_customer_addressのデータを削除
DELETE FROM dtb_customer_address;

-- dtb_cartのデータを削除
DELETE FROM dtb_cart ;

-- dtb_customer_favorite_productのデータを削除
DELETE FROM dtb_customer_favorite_product ;

-- dtb_customerのデータを削除
DELETE FROM dtb_customer ;

-- テストデータの作成

-- dtb_customerの登録
INSERT INTO sagatamaya_ec1.dtb_customer(`id`,`customer_status_id`,`sex_id`,`job_id`,`country_id`,`pref_id`,`name01`,`name02`,`kana01`,`kana02`,`company_name`,`postal_code`,`addr01`,`addr02`,`email`,`phone_number`,`birth`,`password`,`salt`,`secret_key`,`first_buy_date`,`last_buy_date`,`buy_times`,`buy_total`,`note`,`reset_key`,`reset_expire`,`point`,`create_date`,`update_date`,`discriminator_type`,`agent_cd`,`customer_kbn`,`customer_char`,`sales_account_no`,`direct_mail_flg`,`position`,`mobile_phone_number`) VALUES
 (999999950,2,1,1,NULL,5,'会員','ユーザ1','カイイン','ユーザ','（株）会社','0100000','秋田市','1-1-1','sample2@example.com','090987654321',NULL,'8a8c16ce5092925456117c74f67cb3b771606d8c6e2ec3dc1e356fa05882658e','ec7dec691a','tqIqUlSo4kNWHasTRc2B7zgRiWH2U1dE',NULL,NULL,0,0,NULL,NULL,NULL,0,'2022-01-03 05:12:31.000','2022-01-03 05:29:31.000','customer',14,0,NULL,'123123123',0,'肩書',NULL);

-- dtb_customer_addressの登録
INSERT INTO sagatamaya_ec1.dtb_customer_address(`id`,`customer_id`,`country_id`,`pref_id`,`name01`,`name02`,`kana01`,`kana02`,`company_name`,`postal_code`,`addr01`,`addr02`,`phone_number`,`create_date`,`update_date`,`discriminator_type`,`position`,`title`,`accept_no`,`page_no`,`delete_end_season`) VALUES
 (999950,999999950,NULL,5,'会員1','ユーザ1','カイイン','ユーザ','（株）会社','0100001','秋田市中通','1-1-1','090987654322','2022-01-03 05:15:27.000','2022-01-03 05:15:52.000','customeraddress','肩書','様',NULL,NULL,0);

-- dtb_orderの登録
INSERT INTO sagatamaya_ec1.dtb_order(`id`,`customer_id`,`country_id`,`pref_id`,`sex_id`,`job_id`,`payment_id`,`device_type_id`,`pre_order_id`,`order_no`,`message`,`name01`,`name02`,`kana01`,`kana02`,`company_name`,`email`,`phone_number`,`postal_code`,`addr01`,`addr02`,`birth`,`subtotal`,`discount`,`delivery_fee_total`,`charge`,`tax`,`total`,`payment_total`,`payment_method`,`note`,`create_date`,`update_date`,`order_date`,`payment_date`,`currency_code`,`complete_message`,`complete_mail_message`,`add_point`,`use_point`,`order_status_id`,`discriminator_type`,`shop_id`,`floor_id`,`agent_cd`,`member_id`,`sales_account_no`,`ne_cooperation`,`position`) VALUES
 (99999999999999900,NULL,NULL,1,NULL,NULL,7,NULL,'cd7ba83cfa9879ad3c4f9a2ab9adfac983e440bc','99999999999999900',NULL,'非会員','ユーザ1','ヒカイイン','ユーザ','（株）ローカル環境','sample1@gift.com','09012345678','0010010','札幌市北区北十条西','1-1-1',NULL,5001,0,0,0,370,5001,5001,'進物受付',NULL,'2022-01-03 05:04:21.000','2022-01-03 05:05:39.000','2022-01-03 05:05:33.000',NULL,'JPY',NULL,NULL,0,0,1,'order',100,10,13,1,'0123456789',NULL,'肩書'),
 (99999999999999901,999999950,NULL,5,1,1,7,NULL,'761ec970c4fdf4f24dbdfefbf925cdba7e70da3e','99999999999999901',NULL,'会員','ユーザ1','カイイン','ユーザ','（株）会社','sample2@example.com','090987654321','0100000','秋田市','1-1-1',NULL,10002,0,0,0,740,10002,10002,'進物受付',NULL,'2022-01-03 05:29:31.000','2022-01-03 05:30:21.000','2022-01-03 05:05:33.000',NULL,'JPY',NULL,NULL,0,0,1,'order',100,10,14,1,'123123123',NULL,'肩書'),
 (99999999999999902,NULL,NULL,2,2,2,7,NULL,'1','99999999999999902',NULL,'非会員','ユーザ2','ヒカイイン','ユーザ','（株）ローカル環境','sample2@gift.com','09012345680','0000001','パターン7','受注1',NULL,0,0,0,0,0,0,0,'進物受付',NULL,'2022-01-01 05:05:33.000','2022-01-01 05:05:33.000','2022-01-01 05:05:33.000',NULL,'JPY',NULL,NULL,0,0,1,'order',100,10,15,1,'0123456790',NULL,'肩書'),
 (99999999999999903,NULL,NULL,2,2,2,7,NULL,'2','99999999999999903',NULL,'非会員','ユーザ2','ヒカイイン','ユーザ','（株）ローカル環境','sample2@gift.com','09012345680','0000001','パターン7','受注2',NULL,0,0,0,0,0,0,0,'進物受付',NULL,'2022-01-02 05:05:33.000','2022-01-02 05:05:33.000','2022-01-02 05:05:33.000',NULL,'JPY',NULL,NULL,0,0,1,'order',100,10,15,1,'0123456790',NULL,'肩書'),
 (99999999999999904,NULL,NULL,2,2,2,7,NULL,'3','99999999999999904',NULL,'非会員','ユーザ2','ヒカイイン','ユーザ','（株）ローカル環境','sample2@gift.com','09012345680','0000001','パターン7','受注3',NULL,0,0,0,0,0,0,0,'進物受付',NULL,'2022-01-03 05:05:33.000','2022-01-03 05:05:33.000','2022-01-03 05:05:33.000',NULL,'JPY',NULL,NULL,0,0,1,'order',100,10,15,1,'0123456790',NULL,'肩書'),
 (99999999999999905,NULL,NULL,3,1,3,7,NULL,'4','99999999999999905',NULL,'非会員','ユーザ3','ヒカイイン','ユーザ','（株）ローカル環境','sample3@gift.com','09012345681','0000002','パターン9','受注1',NULL,0,0,0,0,0,0,0,'進物受付',NULL,'2022-01-01 05:05:33.000','2022-01-01 05:05:33.000','2022-01-01 05:05:33.000',NULL,'JPY',NULL,NULL,0,0,1,'order',100,10,16,1,'0123456791',NULL,'肩書'),
 (99999999999999906,NULL,NULL,3,1,3,7,NULL,'5','99999999999999906',NULL,'非会員','ユーザ3','ヒカイイン','ユーザ','（株）ローカル環境','sample3@gift.com','09012345681','0000002','パターン9','受注2',NULL,0,0,0,0,0,0,0,'進物受付',NULL,'2022-01-02 05:05:33.000','2022-01-02 05:05:33.000','2022-01-02 05:05:33.000',NULL,'JPY',NULL,NULL,0,0,1,'order',100,10,16,1,'0123456791',NULL,'肩書'),
 (99999999999999907,NULL,NULL,3,1,3,7,NULL,'6','99999999999999907',NULL,'非会員','ユーザ3','ヒカイイン','ユーザ','（株）ローカル環境','sample3@gift.com','09012345681','0000002','パターン9','受注3',NULL,0,0,0,0,0,0,0,'進物受付',NULL,'2022-01-03 05:05:33.000','2022-01-03 05:05:33.000','2022-01-03 05:05:33.000',NULL,'JPY',NULL,NULL,0,0,1,'order',100,10,16,1,'0123456791',NULL,'肩書');

-- dtb_shippingの登録
INSERT INTO sagatamaya_ec1.dtb_shipping(`id`,`order_id`,`country_id`,`pref_id`,`delivery_id`,`creator_id`,`name01`,`name02`,`kana01`,`kana02`,`company_name`,`phone_number`,`postal_code`,`addr01`,`addr02`,`delivery_name`,`time_id`,`delivery_time`,`delivery_date`,`shipping_date`,`tracking_number`,`note`,`sort_no`,`create_date`,`update_date`,`mail_send_date`,`discriminator_type`,`gp_check`,`gp_tie`,`gp_kind`,`gp_butuji`,`gp_calendar`,`gp_package`,`gp_namechoice`,`gp_sonota`,`gp_title`,`gp_name`,`gp_birthday`,`gp_inputsonota`,`position`,`delivery_month`,`delivery_period`,`office_delivery`,`title`) VALUES
 (999900,99999999999999900,NULL,1,182,1,'非会員1','ユーザ1','ヒカイイン','ユーザ','（株）ローカル環境','09012345679','0010011','札幌市北区北十一条西','1-1-1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:04:21.000','2022-01-03 05:05:12.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999901,99999999999999901,NULL,5,182,1,'会員1','ユーザ1','カイイン','ユーザ','（株）会社','090987654322','0100001','秋田市中通','1-1-1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:29:31.000','2022-01-03 05:30:09.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999902,99999999999999901,NULL,5,182,1,'会員1','ユーザ2','カイイン','ユーザ','（株）会社','090987654323','0100002','秋田市東通仲町','1-1-1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999903,99999999999999902,NULL,3,182,1,'非会員2','ユーザ1','ヒカイイン','ユーザ','（株）ローカル環境','09012345681','0000002','パターン7','受注1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999904,99999999999999902,NULL,4,182,1,'非会員2','ユーザ2','ヒカイイン','ユーザ','（株）ローカル環境','09012345682','0000003','パターン7','受注1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999905,99999999999999902,NULL,5,182,1,'非会員2','ユーザ3','ヒカイイン','ユーザ','（株）ローカル環境','09012345683','0000004','パターン7','受注1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999906,99999999999999903,NULL,3,182,1,'非会員2','ユーザ1','ヒカイイン','ユーザ','（株）ローカル環境','09012345681','0000002','パターン7','受注2','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999907,99999999999999903,NULL,4,182,1,'非会員2','ユーザ2','ヒカイイン','ユーザ','（株）ローカル環境','09012345682','0000003','パターン7','受注2','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999908,99999999999999903,NULL,5,182,1,'非会員2','ユーザ3','ヒカイイン','ユーザ','（株）ローカル環境','09012345683','0000004','パターン7','受注2','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999909,99999999999999904,NULL,3,182,1,'非会員2','ユーザ1','ヒカイイン','ユーザ','（株）ローカル環境','09012345681','0000002','パターン7','受注3','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999910,99999999999999904,NULL,4,182,1,'非会員2','ユーザ2','ヒカイイン','ユーザ','（株）ローカル環境','09012345682','0000003','パターン7','受注3','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999911,99999999999999904,NULL,5,182,1,'非会員2','ユーザ3','ヒカイイン','ユーザ','（株）ローカル環境','09012345683','0000004','パターン7','受注3','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999912,99999999999999905,NULL,6,182,1,'非会員3','ユーザ1','ヒカイイン','ユーザ','（株）ローカル環境','09012345684','0000005','パターン9','受注1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999913,99999999999999905,NULL,7,182,1,'非会員3','ユーザ2','ヒカイイン','ユーザ','（株）ローカル環境','09012345685','0000006','パターン9','受注1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999914,99999999999999905,NULL,8,182,1,'非会員3','ユーザ3','ヒカイイン','ユーザ','（株）ローカル環境','09012345686','0000007','パターン9','受注1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999915,99999999999999905,NULL,9,182,1,'非会員3','新規1','ヒカイイン','ユーザ','（株）ローカル環境','09012345687','0000008','パターン9','受注1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999916,99999999999999905,NULL,10,182,1,'非会員3','新規2','ヒカイイン','ユーザ','（株）ローカル環境','09012345688','0000009','パターン9','受注1','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999917,99999999999999906,NULL,6,182,1,'非会員3','ユーザ1','ヒカイイン','ユーザ','（株）ローカル環境','09012345684','0000005','パターン9','受注2','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999918,99999999999999906,NULL,7,182,1,'非会員3','ユーザ2','ヒカイイン','ユーザ','（株）ローカル環境','09012345685','0000006','パターン9','受注2','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999919,99999999999999906,NULL,8,182,1,'非会員3','ユーザ3','ヒカイイン','ユーザ','（株）ローカル環境','09012345686','0000007','パターン9','受注2','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999920,99999999999999906,NULL,11,182,1,'非会員3','新規3','ヒカイイン','ユーザ','（株）ローカル環境','09012345689','0000010','パターン9','受注2','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999921,99999999999999906,NULL,12,182,1,'非会員3','新規4','ヒカイイン','ユーザ','（株）ローカル環境','09012345690','0000011','パターン9','受注2','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999922,99999999999999907,NULL,6,182,1,'非会員3','ユーザ1','ヒカイイン','ユーザ','（株）ローカル環境','09012345684','0000005','パターン9','受注3','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999923,99999999999999907,NULL,7,182,1,'非会員3','ユーザ2','ヒカイイン','ユーザ','（株）ローカル環境','09012345685','0000006','パターン9','受注3','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999924,99999999999999907,NULL,8,182,1,'非会員3','ユーザ3','ヒカイイン','ユーザ','（株）ローカル環境','09012345686','0000007','パターン9','受注3','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999925,99999999999999907,NULL,13,182,1,'非会員3','新規5','ヒカイイン','ユーザ','（株）ローカル環境','09012345691','0000012','パターン9','受注3','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL),
 (999926,99999999999999907,NULL,14,182,1,'非会員3','新規6','ヒカイイン','ユーザ','（株）ローカル環境','09012345692','0000013','パターン9','受注3','送料込（産地加工地直送）',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-03 05:30:09.000','2022-01-03 05:30:21.000',NULL,'shipping',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'肩書',NULL,NULL,0,NULL);

-- dtb_order_itemの登録
INSERT INTO sagatamaya_ec1.dtb_order_item(`id`,`order_id`,`product_id`,`product_class_id`,`shipping_id`,`rounding_type_id`,`tax_type_id`,`tax_display_type_id`,`order_item_type_id`,`product_name`,`product_code`,`class_name1`,`class_name2`,`class_category_name1`,`class_category_name2`,`price`,`quantity`,`tax`,`tax_rate`,`tax_adjust`,`tax_rule_id`,`currency_code`,`processor_name`,`point_rate`,`discriminator_type`,`option_set_flg`,`option_serial`,`custom_product_name`,`accept_no`,`page_no`) VALUES
 (999900,99999999999999900,5943,6029,999900,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000254,NULL),
 (999901,99999999999999901,5943,6029,999901,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000255,NULL),
 (999902,99999999999999901,5943,6029,999902,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000255,NULL),
 (999903,99999999999999902,5943,6029,999903,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000256,NULL),
 (999904,99999999999999902,5943,6029,999904,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000256,NULL),
 (999905,99999999999999902,5943,6029,999905,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000256,NULL),
 (999906,99999999999999903,5943,6029,999906,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000257,NULL),
 (999907,99999999999999903,5943,6029,999907,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000257,NULL),
 (999908,99999999999999903,5943,6029,999908,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000257,NULL),
 (999909,99999999999999904,5943,6029,999909,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000258,NULL),
 (999910,99999999999999904,5943,6029,999910,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000258,NULL),
 (999911,99999999999999904,5943,6029,999911,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000258,NULL),
 (999912,99999999999999905,5943,6029,999912,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000259,NULL),
 (999913,99999999999999905,5943,6029,999913,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000259,NULL),
 (999914,99999999999999905,5943,6029,999914,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000259,NULL),
 (999915,99999999999999905,5943,6029,999915,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000259,NULL),
 (999916,99999999999999905,5943,6029,999916,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000259,NULL),
 (999917,99999999999999906,5943,6029,999917,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000260,NULL),
 (999918,99999999999999906,5943,6029,999918,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000260,NULL),
 (999919,99999999999999906,5943,6029,999919,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000260,NULL),
 (999920,99999999999999906,5943,6029,999920,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000260,NULL),
 (999921,99999999999999906,5943,6029,999921,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000260,NULL),
 (999922,99999999999999907,5943,6029,999922,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000261,NULL),
 (999923,99999999999999907,5943,6029,999923,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000261,NULL),
 (999924,99999999999999907,5943,6029,999924,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000261,NULL),
 (999925,99999999999999907,5943,6029,999925,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000261,NULL),
 (999926,99999999999999907,5943,6029,999926,2,1,1,1,'竹八漬・海幸漬詰合せ','12095219',NULL,NULL,NULL,NULL,4631,1,370,8,0,NULL,'JPY',NULL,NULL,'orderitem',NULL,'{}',NULL,15000261,NULL);
